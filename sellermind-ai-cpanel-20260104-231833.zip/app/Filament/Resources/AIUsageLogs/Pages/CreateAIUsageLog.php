<?php

namespace App\Filament\Resources\AIUsageLogs\Pages;

use App\Filament\Resources\AIUsageLogs\AIUsageLogResource;
use Filament\Resources\Pages\CreateRecord;

class CreateAIUsageLog extends CreateRecord
{
    protected static string $resource = AIUsageLogResource::class;
}
