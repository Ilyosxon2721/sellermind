<?php

namespace App\Filament\Resources\GlobalOptions\Pages;

use App\Filament\Resources\GlobalOptions\GlobalOptionResource;
use Filament\Resources\Pages\CreateRecord;

class CreateGlobalOption extends CreateRecord
{
    protected static string $resource = GlobalOptionResource::class;
}
