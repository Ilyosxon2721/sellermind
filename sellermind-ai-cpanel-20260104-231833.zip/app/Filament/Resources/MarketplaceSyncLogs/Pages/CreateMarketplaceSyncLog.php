<?php

namespace App\Filament\Resources\MarketplaceSyncLogs\Pages;

use App\Filament\Resources\MarketplaceSyncLogs\MarketplaceSyncLogResource;
use Filament\Resources\Pages\CreateRecord;

class CreateMarketplaceSyncLog extends CreateRecord
{
    protected static string $resource = MarketplaceSyncLogResource::class;
}
