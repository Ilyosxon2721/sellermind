<?php

namespace App\Filament\Resources\VpcSessions\Pages;

use App\Filament\Resources\VpcSessions\VpcSessionResource;
use Filament\Resources\Pages\CreateRecord;

class CreateVpcSession extends CreateRecord
{
    protected static string $resource = VpcSessionResource::class;
}
