<?php

namespace App\Services\Products\Publishers;

use App\Models\Product;

class YandexMarketProductPublisher
{
    public function publish(Product $product): void
    {
        // TODO: implement Yandex Market publishing logic / queue dispatch
    }
}
