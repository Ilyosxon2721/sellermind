<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\MarketplaceServiceProvider::class,
    App\Providers\Filament\AdminPanelProvider::class,
];
