# 🔑 Инструкция: Создание токенов Wildberries API

**Дата:** 29 ноября 2025

---

## 📌 Важно знать

Wildberries использует **отдельные токены для каждой категории API**. Вам нужно создать **4 токена** с разными правами доступа.

---

## 🎯 Какие токены нужны

| № | Название токена | Для чего используется |
|---|----------------|---------------------|
| 1 | **Marketplace API Token** | Заказы, остатки, поставки |
| 2 | **Content API Token** | Товары, карточки товаров |
| 3 | **Prices & Discounts API Token** | Цены, скидки |
| 4 | **Statistics API Token** | Статистика, аналитика |

---

## 📋 Шаг 1: Вход в личный кабинет

1. Откройте [seller.wildberries.ru](https://seller.wildberries.ru)
2. Войдите в свой аккаунт продавца
3. Перейдите в раздел **"Настройки"** → **"Доступ к API"**

---

## 🔐 Шаг 2: Создание токенов

### Токен 1: Marketplace API Token (Заказы и остатки)

**Путь:** Настройки → Доступ к API → Создать новый токен

**Выберите следующие разделы:**
- ✅ **Marketplace** (Маркетплейс)
  - ✅ Заказы (Orders)
  - ✅ Поставки (Supplies)
  - ✅ Остатки товаров (Stocks)
  - ✅ Сборочные задания (Assembly tasks)
- ✅ **Warehouses** (Склады)
  - ✅ Просмотр складов

**Название токена:** `SellerMind - Marketplace API`

**Скопируйте токен** → Сохраните в SellerMind как **"Токен Marketplace API"**

---

### Токен 2: Content API Token (Товары)

**Путь:** Настройки → Доступ к API → Создать новый токен

**Выберите следующие разделы:**
- ✅ **Content** (Контент)
  - ✅ Управление карточками товаров (Cards management)
  - ✅ Просмотр карточек (View cards)
  - ✅ Создание карточек (Create cards)
  - ✅ Редактирование карточек (Edit cards)
  - ✅ Медиа файлы (Media files)
- ✅ **Nomenclature** (Номенклатура)
  - ✅ Просмотр номенклатуры

**Название токена:** `SellerMind - Content API`

**Скопируйте токен** → Сохраните в SellerMind как **"Токен Content API"**

---

### Токен 3: Prices & Discounts API Token (Цены и скидки)

**Путь:** Настройки → Доступ к API → Создать новый токен

**Выберите следующие разделы:**
- ✅ **Prices & Discounts** (Цены и скидки)
  - ✅ Управление ценами (Prices management)
  - ✅ Просмотр цен (View prices)
  - ✅ Обновление цен (Update prices)
  - ✅ Управление скидками (Discounts management)
- ✅ **Promotions** (Акции)
  - ✅ Просмотр акций (опционально)

**Название токена:** `SellerMind - Prices API`

**Скопируйте токен** → Сохраните в SellerMind как **"Токен Prices API"**

---

### Токен 4: Statistics API Token (Статистика)

**Путь:** Настройки → Доступ к API → Создать новый токен

**Выберите следующие разделы:**
- ✅ **Statistics** (Статистика)
  - ✅ Статистика продаж (Sales statistics)
  - ✅ Детализация заказов (Order details)
  - ✅ Отчёты (Reports)
- ✅ **Analytics** (Аналитика)
  - ✅ Аналитика товаров (Products analytics)
  - ✅ Финансовая аналитика (Financial analytics)

**Название токена:** `SellerMind - Statistics API`

**Скопируйте токен** → Сохраните в SellerMind как **"Токен Statistics API"**

---

## 💾 Шаг 3: Сохранение токенов в SellerMind

### Вариант A: Через веб-интерфейс

1. Откройте SellerMind AI
2. Перейдите в раздел **"Маркетплейсы"**
3. Найдите **Wildberries** в списке
4. Нажмите кнопку **"Настройки"** (⚙️)
5. Заполните поля:
   ```
   Токен Content API:      [вставьте токен 2]
   Токен Marketplace API:  [вставьте токен 1]
   Токен Prices API:       [вставьте токен 3]
   Токен Statistics API:   [вставьте токен 4]
   ```
6. Нажмите **"Сохранить настройки"**
7. Нажмите **"Проверить подключение"** для тестирования

### Вариант B: Через Tinker (для разработчиков)

```bash
php artisan tinker

$account = App\Models\MarketplaceAccount::where('marketplace', 'wb')->first();

$account->wb_content_token = 'ВАШ_CONTENT_ТОКЕН';
$account->wb_marketplace_token = 'ВАШ_MARKETPLACE_ТОКЕН';
$account->wb_prices_token = 'ВАШ_PRICES_ТОКЕН';
$account->wb_statistics_token = 'ВАШ_STATISTICS_ТОКЕН';

$account->save();

echo "✅ Токены сохранены!\n";
```

### Вариант C: Через тестовый скрипт

```bash
php public/test-wb-sync.php
```

---

## ⚠️ Важные замечания

### Безопасность токенов
- ❌ **Никогда не публикуйте токены в Git**
- ❌ **Не отправляйте токены по email/мессенджерам**
- ✅ Храните токены только в зашифрованном виде
- ✅ SellerMind автоматически шифрует все токены в БД

### Срок действия токенов
- Токены Wildberries обычно **бессрочные**
- Но могут быть отозваны при:
  - Изменении пароля аккаунта WB
  - Ручном удалении в личном кабинете
  - Подозрительной активности

### Обновление токенов
Если токен перестал работать:
1. Удалите старый токен в ЛК Wildberries
2. Создайте новый токен с теми же правами
3. Обновите токен в SellerMind

---

## 🔍 Проверка правильности токенов

После сохранения токенов выполните тест:

```bash
cd /Applications/MAMP/htdocs/sellermind-ai
php public/test-wb-sync.php
```

**Ожидаемый результат при правильных токенах:**

```
🔍 Testing Wildberries API integration...

✅ Found WB account ID: 2
   Name: Тестовый аккаунт Wildberries
   Active: Yes

🔑 Checking credentials:
   api_key: ✅ Present
   wb_marketplace_token: ✅ Present  ← Должно быть ✅
   wb_content_token: ✅ Present      ← Должно быть ✅
   wb_prices_token: ✅ Present       ← Должно быть ✅
   wb_statistics_token: ✅ Present   ← Должно быть ✅

📡 Testing connection...
   Result: {
    "success": true,  ← Должно быть true
    "message": "Wildberries API доступен"
   }

✅ Connection successful!

📦 Fetching orders (last 7 days)...
✅ Orders fetched: 42  ← Количество ваших заказов
```

---

## 🆘 Частые проблемы

### Проблема 1: "IncorrectParameter"
**Причина:** Используется неправильный токен (например, общий api_key вместо wb_marketplace_token)

**Решение:** Убедитесь, что все 4 токена сохранены в системе

---

### Проблема 2: "Unauthorized" (401)
**Причина:** Токен недействителен или отозван

**Решение:**
1. Проверьте токен в ЛК Wildberries
2. Создайте новый токен
3. Обновите в SellerMind

---

### Проблема 3: "Forbidden" (403)
**Причина:** У токена нет нужных прав доступа

**Решение:** Пересоздайте токен с правильными разделами (см. выше)

---

## 📞 Поддержка

Если возникли проблемы:
1. Проверьте логи: `storage/logs/laravel.log`
2. Запустите тест: `php public/test-wb-sync.php`
3. Проверьте статус на странице Marketplace

---

## 🔗 Полезные ссылки

- [Личный кабинет WB](https://seller.wildberries.ru)
- [Документация WB API](https://openapi.wb.ru/)
- [Dev Portal Wildberries](https://dev.wildberries.ru/)

---

**Обновлено:** 29.11.2025, 00:30
**Версия:** 1.0
